package LUXSHOP;

public class Support {
    public void submitQuery(String userEmail, String query) {
        System.out.println(userEmail + "님의 문의: " + query);
    }
}
